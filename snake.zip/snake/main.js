/*
    main.js — Le point d'entrée du jeu.
    C'est le premier fichier chargé par index.html : il attend les ressources,
    prépare l'affichage, place les obstacles, branche le clavier et le menu,
    puis affiche le menu d'accueil. La suite se passe dans menu.js et controller.js.
*/

import { state } from "./config.js";
import { loadAssets } from "./assets.js";
import { createObstacles, loadBestScore } from "./model.js";
import { initController, startGame } from "./controller.js";
import { initMenu } from "./menu.js";
import { initView, render, updateHud, drawLoadingError } from "./view.js";

// On démarre l'application : chargement de la spritesheet, récupération du record,
// placement des obstacles, écoute du clavier, puis affichage du menu.
// Si le chargement échoue, on affiche l'erreur dans le canvas au lieu d'un écran vide.
async function startApp() {
    const canvas = document.getElementById("game-canvas");

    try {
        const assets = await loadAssets();
        initView(canvas, assets.spritesheet);
        loadBestScore(state);
        createObstacles(state);

        // Le bouton "Jouer" du menu lance la partie
        const menu = initMenu({ onPlay: startGame });
        // Échap (pause ou game over) ré-affiche le menu
        initController({ onShowMenu: menu.show });

        updateHud(state);
        render(state);
        menu.show();
    } catch (error) {
        drawLoadingError(canvas, error.message);
        console.error(error);
    }
}

startApp();