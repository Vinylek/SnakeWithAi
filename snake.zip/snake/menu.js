/*
    menu.js — Le menu d'accueil (Jouer, Score, Record, Info).
    C'est un menu HTML posé par-dessus le canvas : plus simple à styler et à
    utiliser au clavier qu'un menu dessiné à la main dans le canvas.
    Ce fichier ne connaît pas les règles du jeu : pour lancer une partie,
    il appelle la fonction onPlay qu'on lui donne (voir main.js).
*/

import { state } from "./config.js";

// Les 4 "pages" du menu : le nom sert dans le code, l'id est celui du HTML
const PANELS = {
    main: "menu-main",
    score: "menu-score",
    record: "menu-record",
    info: "menu-info"
};

// On prépare le menu : clics sur les boutons et navigation au clavier.
// On renvoie show() pour que main.js et le contrôleur puissent rouvrir le menu.
export function initMenu({ onPlay }) {
    const menu = document.getElementById("menu");

    // On affiche une seule page du menu et on cache les autres.
    function showPanel(name) {
        Object.entries(PANELS).forEach(([key, id]) => {
            document.getElementById(id).hidden = key !== name;
        });
        if (name === "score" || name === "record") {
            refreshValues();
        }
        focusFirstButton();
    }

    // On recopie les chiffres actuels du jeu dans les pages Score et Record.
    function refreshValues() {
        document.getElementById("menu-score-value").textContent = state.score;
        document.getElementById("menu-level-value").textContent = state.level;
        document.getElementById("menu-record-value").textContent = state.bestScore;
    }

    // On liste les boutons de la page visible (utile pour naviguer avec les flèches).
    function getVisibleButtons() {
        return [...menu.querySelectorAll(".menu-panel:not([hidden]) button")];
    }

    // On met le focus sur le premier bouton pour pouvoir appuyer sur Entrée tout de suite.
    function focusFirstButton() {
        const buttons = getVisibleButtons();
        if (buttons.length > 0) buttons[0].focus();
    }

    // On affiche le menu, toujours sur sa page principale.
    function show() {
        menu.hidden = false;
        showPanel("main");
    }

    // On cache le menu (quand la partie commence).
    function hide() {
        menu.hidden = true;
    }

    // Clic sur un bouton : on regarde son data-action pour savoir quoi faire.
    function handleClick(event) {
        const button = event.target.closest("button[data-action]");
        if (!button) return;

        const action = button.dataset.action;
        if (action === "play") {
            hide();
            onPlay();
        } else if (action === "back") {
            showPanel("main");
        } else if (action in PANELS) {
            showPanel(action);
        }
    }

    // Clavier : flèches haut/bas pour changer de bouton, Échap pour revenir à la page principale.
    // Entrée et espace fonctionnent tout seuls sur un bouton qui a le focus.
    function handleKeyDown(event) {
        if (menu.hidden) return;

        if (event.key === "Escape") {
            showPanel("main");
            return;
        }
        if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;

        event.preventDefault();
        const buttons = getVisibleButtons();
        const current = buttons.indexOf(document.activeElement);
        const step = event.key === "ArrowDown" ? 1 : -1;
        // Le "+ buttons.length" évite un index négatif quand on remonte depuis le premier bouton
        const next = (current + step + buttons.length) % buttons.length;
        buttons[next].focus();
    }

    menu.addEventListener("click", handleClick);
    document.addEventListener("keydown", handleKeyDown);

    return { show, hide };
}