/*
    controller.js — Le "Controller" du pattern MVC : le clavier et la boucle de jeu.
    Il écoute les touches du joueur, demande au Model de mettre l'état à jour,
    puis demande à la View de redessiner. Il fait le lien entre les deux.
    Tant que le menu est affiché, c'est menu.js qui gère les touches.
*/

import { state, KEYS, DIRECTIONS, GAME_STATUS } from "./config.js";
import { changeDirection, updateGame, resetGame } from "./model.js";
import { render, updateHud } from "./view.js";

// Identifiant du prochain tour de boucle programmé, pour pouvoir l'annuler
let loopTimer = null;

// Fonction à appeler pour afficher le menu HTML (fournie par main.js)
let showMenu = () => {};

// On traduit la touche appuyée en action du jeu ("up", "pause", "start"...).
// On parcourt KEYS et on renvoie le nom de l'action qui contient cette touche, ou null.
function getActionFromKey(key) {
    // On passe en minuscule pour que "Z" (majuscule verrouillée) marche comme "z"
    const normalizedKey = key.length === 1 ? key.toLowerCase() : key;
    const actions = Object.keys(KEYS);
    return actions.find(action => KEYS[action].includes(normalizedKey)) || null;
}

// On lance une nouvelle partie (bouton "Jouer" du menu, ou Entrée après un game over).
// On remet toujours tout à zéro : nouveau serpent, score à 0, nouveaux obstacles.
export function startGame() {
    resetGame(state);
    state.status = GAME_STATUS.PLAYING;
    updateHud(state);
    render(state);
    scheduleNextTick();
}

// Barre espace : on fige la partie, ou on la reprend si elle était déjà en pause.
function togglePause() {
    if (state.status === GAME_STATUS.PLAYING) {
        state.status = GAME_STATUS.PAUSED;
        clearTimeout(loopTimer);
    } else if (state.status === GAME_STATUS.PAUSED) {
        state.status = GAME_STATUS.PLAYING;
        scheduleNextTick();
    }
    render(state);
}

// Échap : on arrête la boucle, on repasse en écran de menu et on affiche le menu HTML.
function goToMenu() {
    clearTimeout(loopTimer);
    state.status = GAME_STATUS.MENU;
    render(state);
    showMenu();
}

// On réagit à une touche : chaque action n'est acceptée que dans le bon écran
// (on ne tourne pas pendant la pause, on ne relance pas une partie déjà en cours...).
function handleKeyDown(event) {
    // Dans le menu, on ne touche à rien : les boutons HTML gèrent Entrée et les flèches
    if (state.status === GAME_STATUS.MENU) return;

    const action = getActionFromKey(event.key);
    if (!action) return;

    // Empêche les flèches et la barre espace de faire défiler la page
    event.preventDefault();

    const canBackToMenu = state.status === GAME_STATUS.PAUSED || state.status === GAME_STATUS.GAME_OVER;

    if (action === "start" && state.status === GAME_STATUS.GAME_OVER) {
        startGame();
    } else if (action === "menu" && canBackToMenu) {
        goToMenu();
    } else if (action === "pause") {
        togglePause();
    } else if (action in DIRECTIONS && state.status === GAME_STATUS.PLAYING) {
        changeDirection(state, action);
    }
}

// On programme le prochain pas du jeu dans state.speedMs millisecondes.
// On utilise setTimeout (et pas setInterval) pour que la vitesse puisse changer
// d'un pas à l'autre quand on passera au niveau supérieur.
function scheduleNextTick() {
    clearTimeout(loopTimer);
    loopTimer = setTimeout(gameTick, state.speedMs);
}

// Un tour de boucle : le Model fait avancer le serpent, la View redessine,
// puis on programme le tour suivant tant que la partie continue.
function gameTick() {
    updateGame(state);
    render(state);
    updateHud(state);
    if (state.status === GAME_STATUS.PLAYING) {
        scheduleNextTick();
    }
}

// On branche l'écoute du clavier sur toute la page.
// onShowMenu = la fonction qui affiche le menu (donnée par main.js).
export function initController({ onShowMenu }) {
    showMenu = onShowMenu;
    document.addEventListener("keydown", handleKeyDown);
}